package com.example.jyotirmani.attendance_college;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

/**
 * Created by Jyotir Mani on 06-04-2017.
 */

public class Admin_login extends AppCompatActivity {
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.admin_login_layout);
    }
}
