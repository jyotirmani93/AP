package com.example.jyotirmani.attendance_college;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;

/**
 * Created by Jyotir Mani on 06-04-2017.
 */

public class Students_home extends AppCompatActivity {
    Button b1,b2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.student_login_layout);
        b1 = (Button)findViewById(R.id.student_login_b);
        b2 = (Button)findViewById(R.id.student_signin_b);

        b1.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v) {
                Intent homeIntent=new Intent(Students_home.this, Student_login.class);
                startActivity(homeIntent);
            }
        });
        b2.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v) {
                Intent homeIntent=new Intent(Students_home.this, Student_signin.class);
                startActivity(homeIntent);
            }
        });




    }
}