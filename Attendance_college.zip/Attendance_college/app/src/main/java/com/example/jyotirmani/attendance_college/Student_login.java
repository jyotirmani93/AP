package com.example.jyotirmani.attendance_college;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.jyotirmani.attendance_college.data.DatabaseHelper;

/**
 * Created by Jyotir Mani on 07-04-2017.
 */

public class Student_login extends AppCompatActivity {
    Button b1,b2;
    EditText e1,e2;
    Database_student myDB;
    String username,password,db_password;

    DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.student_login_layout);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        databaseHelper = new DatabaseHelper(this);

        b1 = (Button)findViewById(R.id.student_login_b);
        myDB = new Database_student(this);
        e1 = (EditText) findViewById(R.id.student_login_e1);
        e2 = (EditText) findViewById(R.id.student_login_e2);
        username = e1.getText().toString();
        password = e2.getText().toString();

        b1.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v) {
                Cursor res=myDB.get_password(username);
                int columnIndex=res.getColumnIndex(Database_student.COL_7);
                db_password=res.getString(columnIndex);
                System.out.println("resource jyotir cursor= "+db_password);
                if(username ==null || password ==null){
                    Toast.makeText(Student_login.this, "Wrong  Credentials ",Toast.LENGTH_SHORT).show();
                    return;
                }
                else if(password.equals(db_password)){
                    // Intent homeIntent=new Intent(Student_login.this, Welcome.class);
                    // startActivity(homeIntent);
                    Toast.makeText(Student_login.this, "welcome",Toast.LENGTH_SHORT).show();
                }
                else {
                    Toast.makeText(Student_login.this, "Wrong  Credentials ",Toast.LENGTH_SHORT).show();
                }
            }
        });

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int itemId = item.getItemId();
        switch (itemId){
            case android.R.id.home:
                onBackPressed();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private int checkAccount(String userId, String password){
        SQLiteDatabase db = databaseHelper.getReadableDatabase();
        return 0;
    }
}
