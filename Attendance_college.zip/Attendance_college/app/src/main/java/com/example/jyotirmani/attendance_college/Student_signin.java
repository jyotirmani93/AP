package com.example.jyotirmani.attendance_college;

import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

/**
 * Created by Jyotir Mani on 06-04-2017.
 */

public class Student_signin extends ActionBarActivity {
    Database_student myDB;
    Button b1;
    EditText e1, e2, e3, e4, e5, e6;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.student_signin_layout);
        myDB = new Database_student(this);
        e1 = (EditText) findViewById(R.id.student_signin_e1);
        e2 = (EditText) findViewById(R.id.student_signin_e2);
        e3 = (EditText) findViewById(R.id.student_signin_e3);
        e4 = (EditText) findViewById(R.id.student_signin_e4);
        e5 = (EditText) findViewById(R.id.student_signin_e5);
        e6 = (EditText) findViewById(R.id.student_signin_e6);

        b1 = (Button) findViewById(R.id.student_signin_b);

        addData();
    }

    public void addData() {
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                boolean isInserted = myDB.insertData(e1.getText().toString(), e2.getText().toString(), e3.getText().toString(),e4.getText().toString(), e5.getText().toString(), e5.getText().toString());
                if (isInserted == true)
                    Toast.makeText(Student_signin.this, "data inserted", Toast.LENGTH_SHORT).show();
                else
                    Toast.makeText(Student_signin.this, "data not inserted", Toast.LENGTH_SHORT).show();

            }
        });
    }

}