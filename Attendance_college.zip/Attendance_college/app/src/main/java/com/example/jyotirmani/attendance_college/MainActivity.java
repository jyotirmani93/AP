package com.example.jyotirmani.attendance_college;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    Button b1,b2,b3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        b1 = (Button)findViewById(R.id.home_b1);
        b2 = (Button)findViewById(R.id.home_b2);
        b3 = (Button)findViewById(R.id.home_b3);

        b1.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v) {
                Intent homeIntent=new Intent(MainActivity.this, Teachers_login.class);
                startActivity(homeIntent);
            }
        });
        b2.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v) {
                Intent homeIntent=new Intent(MainActivity.this, Students_home.class);
                startActivity(homeIntent);
            }
        });
        b3.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v) {
                Intent homeIntent=new Intent(MainActivity.this, Admin_login.class);
                startActivity(homeIntent);
            }
        });



    }
}

