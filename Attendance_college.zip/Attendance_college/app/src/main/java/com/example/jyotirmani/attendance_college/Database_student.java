package com.example.jyotirmani.attendance_college;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * Created by Jyotir Mani on 06-04-2017.
 */

public class Database_student extends SQLiteOpenHelper {

    public static final String DATABASE_NAME = "Student.db";
    public static final int DATABASE_VERSION = 1;
    //public static final String TABLE_NAME = "student_table";
//    public static final String COL_1 = "ID";
//    public static final String COL_2 = "NAME_OF_STUDENT";
//    public static final String COL_3 = "COURSE";
//    public static final String COL_4 = "SEMESTER";
//    public static final String COL_5 = "ROLL_NUMBER";
//    public static final String COL_6 = "USERID";
//    public static final String COL_7 = "PASSWORD";


    //Database_student db;
    //CREATES OUR DATABASE
    public Database_student(Context context) {
        super(context, DATABASE_NAME, null, 1);
    }

    //IT PASSES OUR QUERY
    @Override
    public void onCreate(SQLiteDatabase db) {
//        db.execSQL("create table " + TABLE_NAME + " (ID INTEGER PRIMARY KEY AUTOINCREMENT, NAME_OF_STUDENT TEXT, COURSE TEXT," + COL_4 + " INTEGER, ROLL_NUMBER INTEGER, USERID TEXT, PASSWORD TEXT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
//        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);
    }
//    public boolean insertData(String name,String course, String sem, String rollno, String userid, String password){
//        SQLiteDatabase db=this.getWritableDatabase();
//        ContentValues contentValues=new ContentValues();
//        contentValues.put(COL_2,name);
//        contentValues.put(COL_3,course);
//        contentValues.put(COL_4,sem);
//        contentValues.put(COL_5,rollno);
//        contentValues.put(COL_6,userid);
//        contentValues.put(COL_7,password);
//
//
//        long result = db.insert(TABLE_NAME, null, contentValues);
//        if(result > 0)
//            return false;
//        else
//            return true;
//    }
//    public Cursor getAllData(){
//        SQLiteDatabase db=this.getWritableDatabase();
//        Cursor res=db.rawQuery("select * from "+TABLE_NAME, null);
//        return res;
//    }
//    String[] result_column = new String[]{PASSWORD};
//
//    public Cursor get_password(String username){
//        SQLiteDatabase db=this.getWritableDatabase();
//        String where = COL_6 +"="+ username;
//        Cursor cursor=db.query(Database_student.TABLE_NAME,result_column,where,null,null,null,null);
//        return cursor;
//    }

}

