package com.example.jyotirmani.attendance_college.data;

import android.provider.BaseColumns;

/**
 * Created by Jyotir Mani on 10-04-2017.
 */

public final class DatabaseContract {

    public static class StudentEntry implements BaseColumns {
        public static final String TABLE_NAME = "student";
        public static final String COLUMN_NAME = "name";
        public static final String COLUMN_COURSE = "course";
        public static final String COLUMN_SEMESTER = "semester";
        public static final String COLUMN_ROLL_NO = "roll_no";
        public static final String COLUMN_USER_ID = "user_id";
        public static final String COLUMN_PASSWORD = "password";

        public static final String CREATE_TABLE_ENTRY = "CREATE TABLE " + TABLE_NAME + " { "
                + _ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + COLUMN_NAME + " TEXT NOT NULL, "
                + COLUMN_COURSE + " TEXT NOT NULL, "
                + COLUMN_SEMESTER + " INTEGER NOT NULL, "
                + COLUMN_ROLL_NO + " INTEGER NOT NULL UNIQUE, "
                + COLUMN_USER_ID + " TEXT NOT NULL UNIQUE, "
                + COLUMN_PASSWORD + " TEXT NOT NULL"
                + " };";

        public static final String DROP_TABLE = "DROP TABLE IF EXISTS " + TABLE_NAME;
    }

}
