package com.example.jyotirmani.attendance_college;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

/**
 * Created by Jyotir Mani on 07-04-2017.
 */

public class Welcome extends AppCompatActivity {
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.teacher_login_layout);

    }
}
